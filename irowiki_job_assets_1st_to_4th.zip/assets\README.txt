iRO Wiki Skill Simulator â€” Job assets

Fuente: https://skills.irowiki.org/

Contenido:
- 1st_class: 11 jobs
- 2nd_class: 15 jobs
- 3rd_class: 19 jobs
- 4th_class: 20 jobs
- Total: 65 jobs

Cada categorÃ­a contiene:
- characters/: imagen del personaje/job
- icons/: icono del job
- backgrounds/: cuatro estados originales del recuadro

Los recursos se conservaron en su formato original y sin recomprimir.
manifest.csv incluye IDs, nombres, rutas locales y URLs de origen.
Recolectado el 27 de julio de 2026.